# Install pdftools
install.packages("pdftools")

# Install tm
install.packages("tm")

# Install lsa
install.packages("lsa")

# Install LSAfun
install.packages("LSAfun")


require(pdftools)
require(tm)
require(lsa)
require(LSAfun)

files <- list.files(pattern = "pdf$")

docs <- sapply(files, pdf_text,USE.NAMES = TRUE)

lAcorp <- Corpus(VectorSource(docs))

szCorpus <- tm_map(lAcorp, content_transformer(tolower))
szCorpus <- tm_map(szCorpus, removePunctuation)
szCorpus <- tm_map(szCorpus, removeNumbers)
szCorpus <- tm_map(szCorpus, removeWords, stopwords("english"))
szCorpus <- tm_map(szCorpus, stripWhitespace)

TDM <- TermDocumentMatrix(szCorpus)

lsaTdmSpace = lsa(TDM, dims = 20)

as.textmatrix(lsaTdmSpace)

